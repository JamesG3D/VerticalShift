﻿using UnityEngine;
using System.Collections;

public interface IFireable {
	void fireDown();
	void fireUp();
}
